#include "stdafx.h"
#include "SocketBuffer.hpp"

SocketBuffer::SocketBuffer() : current_size_(0) 
{
	buffer_ = new char[max_buff_];
}

SocketBuffer::~SocketBuffer()
{
	delete[] buffer_;
}


void SocketBuffer::add(const char *data, int size) 
{
	if (size < 1) return;

	if (current_size_ + size > max_buff_) throw SocketBufferException();
	
	// copy the content of the buffer passed as parameter to the internal buffer
	memcpy(buffer_ + current_size_, data, size);
	current_size_ += size;
}

void SocketBuffer::replace(const char* data, int size)
{
	if (size < 1) return;

	if (size > max_buff_ || size < 0 ) throw SocketBufferException();

	memset(buffer_, 0, max_buff_);
	memcpy(buffer_, data, size);
	current_size_ = size;
}


void SocketBuffer::clear()
{
	memset(buffer_, 0, max_buff_);
	current_size_ = 0;
}

int SocketBuffer::get_max_size()
{
	return max_buff_;
}

int SocketBuffer::get_size()
{
	return current_size_;
}

char* SocketBuffer::get_buffer()
{
	return buffer_;
}

void SendSocketBuffer::send(int n)
{
	if (n < 1) return;

	if (n > current_size_ || n >  current_size_ - read_position_) throw SocketBufferException();
	
	// change the buffer position
	read_buffer_ += n;
	read_position_ += n;
} 

int SendSocketBuffer::get_bytes_sent()
{
	return read_position_;
}

char* SendSocketBuffer::get_buffer()
{
	return read_buffer_;
}

int SendSocketBuffer::get_remaining_bytes()
{
	return current_size_ - read_position_;
}

void SendSocketBuffer::replace(const char* data, int size)
{
	if (size < 1) return;

	if (size > max_buff_) throw SocketBufferException();
	
	memset(buffer_, 0, max_buff_);
	memcpy(buffer_, data, size);
	current_size_ = size;

	read_buffer_ = buffer_;
	read_position_ = 0;
}

void SendSocketBuffer::clear()
{
	memset(buffer_, 0, max_buff_);
	current_size_ = 0;

	read_buffer_ = buffer_;
	read_position_ = 0;
}










