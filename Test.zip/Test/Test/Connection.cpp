#include "stdafx.h"
#include "Connection.hpp" 


using namespace connection;

TCPConnection::TCPConnection(const char* host, const int port) : alive(true)
{
	int n;
	struct addrinfo hints, *res, *res0;

	if (port < 0 || port > 65535)
		throw SocketException(1);

	std::string char_port = std::to_string(port);

	memset(&hints, 0, sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;

	if ((n = getaddrinfo(host, char_port.c_str(), &hints, &res0)) != 0) 
		std::cout << "Error within getaddrinfo(): " << WSAGetLastError() << std::endl;
		

	sock_ = -1;
	for (res = res0; res != nullptr; res = res->ai_next) {

		sock_ = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
		if (sock_ == INVALID_SOCKET) {
			std::cout << "(%s) socket() failed" << std::endl;
			continue;
		}

		std::cout << "(%s) --- Socket created, fd number: " << sock_ << std::endl;

		if (connect(sock_, res->ai_addr, res->ai_addrlen) < 0) {
			closesocket(sock_);	/* bind error, close and try next one */
			continue;
		}

		/*std::cout << "(%s) --- Connected to target address: " 
		<< inet_ntoa(((struct sockaddr_in *)(res->ai_addr))->sin_addr) << ":"
		<< htons(((struct sockaddr_in *)(res->ai_addr))->sin_port) << std::endl;
		*/

		// TODO cambaire 
		remote_address_ = *((struct sockaddr_in *)(res->ai_addr));
		break; /* Ok we got one */
	}

	if (res == NULL) {	/* errno set from final connect() */
		std::cout << "Couldn't connect to " << host << ":" << port << " because of error " << WSAGetLastError() << std::endl;
		throw SocketException(1);
	}

	freeaddrinfo(res0);
}


TCPConnection::TCPConnection(SOCKET socket, SOCKADDR_IN socket_address) : alive(true)
{
	sock_ = socket; 
	remote_address_ = socket_address;
}


void TCPConnection::close_connection() const {

	if (alive) {
		if (closesocket(sock_) == SOCKET_ERROR) {
			if (WSAGetLastError() == WSAENOTSOCK)
				std::cout << "Failed to close the socket. Winsock Error: " + std::to_string(WSAGetLastError()) + "!" << std::endl;
		}
	} 

}

/**
* \brief print on standard output the information about the remote endpoint assoicated with the TCP connection
*/
void TCPConnection::print_endpoint_info() const {
	char client_address[INET_ADDRSTRLEN];
	inet_ntop(AF_INET, &(remote_address_.sin_addr), client_address, INET_ADDRSTRLEN);

	if (sock_ == 0) {
		std::cout << "socket not connected" << std::endl;
		return;
	}

	std::cout << "IP address: " << client_address << std::endl;
	std::cout << "port number: " << ntohs(remote_address_.sin_port) << std::endl << std::endl;
}

/**
* \brief
* \param data : buffer filled with data received
* \param totalByte : number of bytes to be read
* \param totalReadByte : number of Bytes really read
* \return false if the connection has been closed by peer, otherside true
*/
bool TCPConnection::recv_all(std::shared_ptr<SocketBuffer> buffer, int size) {

	if (size > buffer->get_max_size()) throw SocketException(1);

	auto *local_buffer = new char[buffer->get_max_size()];
	int byte_received = 0, byte_read = 0;

	buffer->clear();

	try
	{
		while (byte_received < size && alive) {
			byte_read = read_select(sock_, local_buffer, size - byte_received);

			if (byte_read == SOCKET_ERROR) {
				delete[] local_buffer;
				throw SocketException(WSAGetLastError());
			}

			// the connection is closed 
			if (byte_read == 0) alive = false;
			else
			{
				byte_received += byte_read;					// increment the number of bytes received
				buffer->add(local_buffer, byte_read);
			}
			
		}
	} catch(SocketException &se)
	{
		delete[] local_buffer;
		throw;
	} catch(TimeoutException &te)
	{
		delete[] local_buffer;
		throw;
	}
	
	// deallocate the local buffer
	delete[] local_buffer;

	return alive;
}

/**
* \brief
* \param data : buffer used to send the data
* \param totalByte : # of bytes to be sent
* \param totalSentByte : reference type, total number of bytes really sent
* \return false if the connection has been closed by peer, true if the data has been sent correctly
*/
bool TCPConnection::send_all(std::shared_ptr<SendSocketBuffer> buffer) {
	const int total_bytes = buffer->get_size();
	int sent_bytes = 0;

	while (buffer->get_bytes_sent() < total_bytes) {

		sent_bytes = send(sock_, buffer->get_buffer(), buffer->get_remaining_bytes(), 0);
		
		if (sent_bytes == 0) return false;

		if (sent_bytes == SOCKET_ERROR) throw SocketException(WSAGetLastError());
		
		buffer->send(sent_bytes);
	}

	return true;
}

/**
* \brief
* \param data : buffer used to write the dato
* \param readByte : reference value, total number of byte read
* \param maxByte : max # of Bytes that can be read
* \return false if the connection has been closed by peer, true if the data are read correclty
*/
bool TCPConnection::read_line(char *data, const int maxBytes, int& readBytes) {

	const int read_byte = readline_unbuffered(data, (size_t) maxBytes);

	if (read_byte == 0) return false;

	if (read_byte < 0) throw SocketException(WSAGetLastError());

	readBytes = read_byte;
	return true;
}

size_t TCPConnection::readline_unbuffered(char *vptr, size_t maxlen) {

	size_t n, rc;
	char c, *ptr;

	ptr = vptr;
	for (n = 1; n<maxlen; n++) {
		if ((rc = recv(sock_, &c, 1, 0)) == 1) {
			*ptr++ = c;
			if (c == '\n')
				break;	/* newline is stored, like fgets() */
		}
		else if (rc == 0) {
			if (n == 1)
				return 0; /* EOF, no data read */
			else
				break; /* EOF, some data was read */
		}
		else
			return -1; /* error, errno set by read() */
	}
	*ptr = 0; /* null terminate like fgets() */

	return n;
}

size_t TCPConnection::read_select(SOCKET socket, char *read_buffer, int size)
{
	struct timeval time;
	FD_SET read_sock;

	FD_ZERO(&read_sock);
	FD_SET(socket, &read_sock);

	time.tv_sec = sec_;
	time.tv_usec = usec_;

	const int result = select(1, &read_sock, nullptr, nullptr, &time);

	if (result == SOCKET_ERROR) throw SocketException(1);
	
	if (result == 0) throw TimeoutException();

	if (result > 1) return recv(sock_, read_buffer, size, 0);
}
