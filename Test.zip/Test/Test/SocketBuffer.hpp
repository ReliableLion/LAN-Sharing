#pragma once
#include <memory>
#include <vector>
#include <cstring>

#include "Exceptions.hpp"
#include "Constants.hpp"

class SocketBuffer
{
protected:
	char  *buffer_;
	const int max_buff_ = BUFFER_SIZE;
	int current_size_ = 0;
public:
	SocketBuffer();
	~SocketBuffer();
	void add(const char *data, int size);
	virtual void clear();
	virtual void replace(const char *data, int size);
	virtual char* get_buffer();
	int get_size();
	int get_max_size();
};


class SendSocketBuffer : public SocketBuffer
{
private: 
	int read_position_;
	char *read_buffer_;
public: 
	SendSocketBuffer() : SocketBuffer(), read_position_(0) { read_buffer_ = buffer_; };
	void send(int n);
	void replace(const char* data, int size);
	void clear();
	char* get_buffer() override;
	int get_bytes_sent();
	int get_remaining_bytes();
};
